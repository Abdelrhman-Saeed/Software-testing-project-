package tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;

public class Login_NegativeScenario extends TestBase {
	
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
	
	long time = System.currentTimeMillis();
 
  
  @Test(priority = 1)
  public void userNameMissmatch_NegativeScenario() throws InterruptedException {
	  homeObject = new HomePage(driver);
	  logInObject = new LoginPage(driver);
	  
	  homeObject.UserLogsOutbtn();
	  
	  logInObject.RegisteredUserLogIn( "alex"+time,"bank");
	  
	  Assert.assertTrue(logInObject.errorLoginMSG.isDisplayed());
	  
  }
  
  @Test(priority = 2)
  public void passwordMissmatch_NegativeScenario() throws InterruptedException {
	  logInObject = new LoginPage(driver);
	  
	  logInObject.RegisteredUserLogIn( "para"+time,"tank");
	  Thread.sleep(500);
	  Assert.assertTrue(logInObject.errorLoginMSG.isDisplayed());
  }
  
  
  
  
  
}
