package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BillpaymentPage;
import pages.HomePage;
public class Billpay_NegativeScenario extends TestBase{
		HomePage homeOpject;
		BillpaymentPage billOpject;
		
@Test
	public void billpay_NegativeScenario() throws InterruptedException {
		homeOpject = new HomePage(driver);
		billOpject = new BillpaymentPage(driver);
		
		homeOpject.goToBillpay();
			Thread.sleep(1000);
		Assert.assertTrue(billOpject.billservicesMSG.isDisplayed());
		
		billOpject.fillBillPayData("", "", "", "", "","", "", "", "");
			Thread.sleep(3000);
			
		Assert.assertTrue(billOpject.payeeNamerequieredsMSG.isDisplayed());
		Assert.assertTrue(billOpject.zipcoderequieredMSG.isDisplayed());
		Assert.assertTrue(billOpject.amountrequieredMSG.isDisplayed());
	
	}

}
