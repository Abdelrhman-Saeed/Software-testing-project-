package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RequestLoanPage;

public class RequestLoan extends TestBase{
	
	HomePage HomeOpject;
	RequestLoanPage RequestLoanOpject;
	
	
  @Test
  public void RequestLoan_JustHappyScenario() throws InterruptedException {
	  HomeOpject = new HomePage(driver);
	  RequestLoanOpject = new RequestLoanPage(driver);
	  
	  HomeOpject.goToRequestLoan();
	 Assert.assertTrue(RequestLoanOpject.applyForLoanMSG.isDisplayed());
	 
	  RequestLoanOpject.requestLoan("100", "20");
	  Thread.sleep(1000);
	 Assert.assertTrue(RequestLoanOpject.processedMSG.isDisplayed()); 
	  
	  
  }
  
  
  
}
