//package Tests;
//
//import Pages.FindTransactionsPage;
//import Pages.HomePage;
//import Pages.RegisterPage;
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
//public class FindTransactionsTest extends TestBase {
//
//    @Test
//    public void testFindAllSearchMethods() {
//
//        // Step 1 - Register
//        RegisterPage reg = new RegisterPage(driver);
//        reg.openRegisterPage();
//        reg.enterFirstName("Mohamed");
//        reg.enterLastName("Ali");
//        reg.enterAddress("Cairo");
//        reg.enterCity("Cairo");
//        reg.enterState("CA");
//        reg.enterZip("12345");
//        reg.enterPhone("01000000000");
//        reg.enterSSN("55555");
//        reg.enterUsername("mohamedX");
//        reg.enterPassword("123456");
//        reg.confirmPassword("123456");
//        reg.clickRegisterBtn();
//
//        // Step 2 - Go to Find Transactions
//        HomePage home = new HomePage(driver);
//        home.navigateToFindTransactionPage();
//
//        FindTransactionsPage find = new FindTransactionsPage(driver);
//
//        // Select Account
//        find.selectAccount("13788");
//
//        // Step 3 - Search by ID
//        find.searchByTransactionId("12345");
//        Assert.assertTrue(find.resultsShown());
//
//        // Step 4 - Search by Date
//        find.searchByDate("01-05-2024");
//        Assert.assertTrue(find.resultsShown());
//
//        // Step 5 - Date Range
//        find.searchByDateRange("01-01-2024", "01-10-2024");
//        Assert.assertTrue(find.resultsShown());
//
//        // Step 6 - By Amount
//        find.searchByAmount("100");
//        Assert.assertTrue(find.resultsShown());
//    }
//}