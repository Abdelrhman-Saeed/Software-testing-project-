package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.TransferFundsPage;

public class TransferFunds_JustHappy extends TestBase{
	HomePage HomeOpject;
	TransferFundsPage TransferObject;
  @Test
  public void transferFunds_JustHappy() throws InterruptedException {
	  
	  HomeOpject = new HomePage(driver);
	  TransferObject = new TransferFundsPage(driver);
	  
	  HomeOpject.goToTransferFunds();
	  Thread.sleep(1000);
	  Assert.assertTrue(TransferObject.transferFundsMSG.isDisplayed());
	  
	  
	  TransferObject.transferFunds("100");
	  Thread.sleep(1000);
	  Assert.assertTrue(TransferObject.transferComplete.isDisplayed());
	  
  }
}
