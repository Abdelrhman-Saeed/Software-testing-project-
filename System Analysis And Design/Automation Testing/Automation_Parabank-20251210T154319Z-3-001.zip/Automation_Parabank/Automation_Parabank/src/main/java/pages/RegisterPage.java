package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class RegisterPage extends PageBasePara{
	
	public RegisterPage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(id="customer.firstName")
	WebElement firstNameTxt;
	
	@FindBy(id="customer.lastName")
	WebElement lastNameTxt;
	
	@FindBy(id="customer.address.street")
	WebElement addressTxt;
	
	@FindBy(id="customer.address.city")
	WebElement cityTxt;
	
	@FindBy(id="customer.address.state")
	WebElement stateTxt;
	
	@FindBy(id="customer.address.zipCode")
	WebElement zipCodeTxt;
	
	@FindBy(id="customer.phoneNumber")
	WebElement phoneTxt;
	
	@FindBy(id="customer.ssn")
	WebElement ssnTxt;
	
	@FindBy(id="customer.username")
	 WebElement userNameTxt;
	
	@FindBy(id="customer.password")
	WebElement passWordTxt;
	
	@FindBy(id="repeatedPassword")
	WebElement confirmPassWordTxt;
	
	@FindBy(xpath="//*[@id=\"customerForm\"]/table/tbody/tr[13]/td[2]/input")
	WebElement registerBtn;
	
	@FindBy(xpath = "//*[@id=\"rightPanel\"]/h1")
	public WebElement regesterPageMSG;
	

/////////////////////////////////// Samples not all error messages    ///
@FindBy(xpath = "//*[@id=\"customer.firstName.errors\"]")
public WebElement firstNameRequieredMSG;

@FindBy(xpath = "//*[@id=\"customer.address.state.errors\"]")
public WebElement stateRequieredMSG;

@FindBy(xpath = "//*[@id=\"customer.username.errors\"]")
public WebElement userNameRequieredMSG;
////////////////////////////////////////////////////////////////////////
	
	
	
	public void customerCanRegister(String firstName , String lastName ,  String address , String  city,
     	String state,  String zipCode , String phone  , String ssn,  String userName , String password )
	{
	        
		firstNameTxt.sendKeys(firstName);
		lastNameTxt.sendKeys(lastName);
		
		addressTxt.sendKeys(address);
		cityTxt.sendKeys(city);
		stateTxt.sendKeys(state);
		zipCodeTxt.sendKeys(zipCode);
		
		phoneTxt.sendKeys(phone);
		ssnTxt.sendKeys(ssn);
		
	    userNameTxt.sendKeys(userName);
		passWordTxt.sendKeys(password);
		confirmPassWordTxt.sendKeys(password);
		
		registerBtn.click();
	}
	
	
	
}
