//package pages;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.ui.Select;
//
//public class FindTransactionsPage extends PageBase {
//
//    public FindTransactionsPage(WebDriver driver) {
//        super(driver);
//    }
//
//    // ====================== LOCATORS ======================
//
//    private By accountSelect = By.id("accountId");
//
//    // Transaction ID
//    private By transactionIdInput = By.id("transactionId");
//
//    // Date
//    private By dateInput = By.id("transactionDate");
//
//    // Date Range
//    private By fromDateInput = By.id("fromDate");
//    private By toDateInput = By.id("toDate");
//
//    // Amount
//    private By amountInput = By.id("amount");
//
//    // ====== BUTTONS (By order in page) ======
//    private By findByTransactionIdBtn = By.xpath("(//button[text()='Find Transactions'])[1]");
//    private By findByDateBtn = By.xpath("(//button[text()='Find Transactions'])[2]");
//    private By findByDateRangeBtn = By.xpath("(//button[text()='Find Transactions'])[3]");
//    private By findByAmountBtn = By.xpath("(//button[text()='Find Transactions'])[4]");
//
//    // Results Table
//    private By resultTable = By.id("transactionTable");
//
//
//    // ====================== METHODS ======================
//
//    // Select Account Number
//    public void selectAccount(String accountNumber) {
//        Select select = new Select(waitElement(accountSelect));
//        select.selectByVisibleText(accountNumber);
//    }
//
//    // Search by Transaction ID
//    public void searchByTransactionId(String id) {
//        waitElement(transactionIdInput).clear();
//        waitElement(transactionIdInput).sendKeys(id);
//        waitElement(findByTransactionIdBtn).click();
//    }
//
//    // Search by Date
//    public void searchByDate(String date) {
//        waitElement(dateInput).clear();
//        waitElement(dateInput).sendKeys(date);
//        waitElement(findByDateBtn).click();
//    }
//
//    // Search by Date Range
//    public void searchByDateRange(String from, String to) {
//        waitElement(fromDateInput).clear();
//        waitElement(fromDateInput).sendKeys(from);
//
//        waitElement(toDateInput).clear();
//        waitElement(toDateInput).sendKeys(to);
//
//        waitElement(findByDateRangeBtn).click();
//    }
//
//    // Search by Amount
//    public void searchByAmount(String amount) {
//        waitElement(amountInput).clear();
//        waitElement(amountInput).sendKeys(amount);
//        waitElement(findByAmountBtn).click();
//    }
//
//    // To confirm results table
//    public boolean resultsShown() {
//        return waitElement(resultTable).isDisplayed();
//    }
//}