package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class OpenNewAccPage extends PageBasePara{

	public OpenNewAccPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id="type")
	WebElement accountTybeList;
	
	@FindBy(id="fromAccountId")
	WebElement fromAccountList;
	
	@FindBy(xpath = "//*[@id=\"openAccountForm\"]/form/div/input")
	WebElement openNewAccBtn;
	
	
	@FindBy(id="newAccountId")
	WebElement newAccDetailsBtn;
	
	
	@FindBy(id="month")
	WebElement accountActivityPeriodList;
	
	@FindBy(id="transactionType")
	WebElement accountCardTypeList;
	
	@FindBy(xpath = "//*[@id=\"activityForm\"]/table/tbody/tr[3]/td[2]/input")
	WebElement goCheckDetailsBtn;
	
	
	@FindBy(xpath = "//*[@id=\"openAccountForm\"]/h1")
	public WebElement openNewAccountMSG;
	
	@FindBy(xpath = "//*[@id=\"openAccountResult\"]/p[1]")
	public WebElement congratulationMSG;
	
	
	public void openNewAccount() {
		
		Select accountTypeList = new Select(accountTybeList);
		Select accountNumberList = new Select(fromAccountList);
		
		accountTypeList.selectByIndex(1);
		accountNumberList.getFirstSelectedOption();
		
		openNewAccBtn.click();
	}
	
	public void openAccountDetailsPage() {
		newAccDetailsBtn.click();
	}
	
	public void userCanCheckNewAccountActivity() {
		Select activePeriodList = new Select (accountActivityPeriodList);
		Select cardTypeList = new Select (accountCardTypeList);
		
		activePeriodList.selectByValue("All");
		cardTypeList.selectByValue("All");
		
		goCheckDetailsBtn.click();
	}
	
}
