package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class BillpaymentPage extends PageBasePara{


	public BillpaymentPage(WebDriver driver) {
		super(driver);
	}

	
	@FindBy(linkText = "Bill Pay")
	WebElement billPayLink;

	@FindBy(name = "payee.name")
	WebElement payeeNameTxt;
	@FindBy(name = "payee.address.street")
	WebElement streetTxt;
	@FindBy(name = "payee.address.city")
	WebElement cityTxt;
	@FindBy(name = "payee.address.state")
	WebElement stateTxt;
	@FindBy(name = "payee.address.zipCode")
	WebElement zipTxt;
	@FindBy(name = "payee.phoneNumber")
	WebElement phoneTxt;

	@FindBy(name = "payee.accountNumber")
	WebElement accountTxt;
	@FindBy(name = "verifyAccount")
	WebElement verifyAccountTxt;
	@FindBy(name = "amount")
	WebElement amountTxt;

	@FindBy(name = "fromAccountId")
	WebElement fromAccountList;
	@FindBy(xpath = "//*[@id=\"billpayForm\"]/form/table/tbody/tr[14]/td[2]/input")
	WebElement sendPaymentBtn;
	
	@FindBy(xpath = "//*[@id=\"billpayForm\"]/h1")
	public WebElement billservicesMSG;

	
	@FindBy(xpath = "//*[@id=\"billpayResult\"]/h1")
	public WebElement billcompleteMSG;
	
	
	@FindBy(id = "validationModel-name")
	public WebElement payeeNamerequieredsMSG;
	
	
	@FindBy(id = "validationModel-zipCode")
	public WebElement zipcoderequieredMSG;
	
	
	@FindBy(id = "validationModel-amount-empty")
	public WebElement amountrequieredMSG;
	
	
	
	
	
	
	// ===== BillPay Mutual Data Method =====
	public void fillBillPayData(String Payeename , String address, String city,
			String state,String zipcode,String phone,
			String account, String verify, String amount) {
		
		Select fromList = new Select(fromAccountList);
		
		payeeNameTxt.sendKeys(Payeename);
		streetTxt.sendKeys(address);
		cityTxt.sendKeys(city);
		stateTxt.sendKeys(state);
		zipTxt.sendKeys(zipcode);
		phoneTxt.sendKeys(phone);
		
		accountTxt.sendKeys(account);
		verifyAccountTxt.sendKeys(verify);
		amountTxt.sendKeys(amount);
		
		fromList.getFirstSelectedOption();
		
		sendPaymentBtn.click();
	}
	
}
