package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ForgetLoginInfoPage extends PageBasePara {

	public ForgetLoginInfoPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id="firstName")
	WebElement firstNameTxt;
	
	@FindBy(id="lastName")
	WebElement lastNameTxt;
	
	@FindBy(id="address.street")
	WebElement addressTxt;
	
	@FindBy(id="address.city")
	WebElement cityTxt;
	
	@FindBy(id="address.state")
	WebElement stateTxt;
	
	@FindBy(id="address.zipCode")
	WebElement zipCodeTxt;
	
	@FindBy(id="ssn")
	WebElement ssnTxt;
	
	@FindBy(xpath="//*[@id=\"lookupForm\"]/table/tbody/tr[8]/td[2]/input")
	WebElement findMyLogInInfoBtn;
	
	
	@FindBy(xpath="//*[@id=\"rightPanel\"]/h1")
	public WebElement customerLookupMSG;
	
	@FindBy(xpath =   "//*[@id=\"rightPanel\"]/p")
	public WebElement infoCouldNotBeFoundMSG;
	
	
	
	public void findMyLogInInfo(String firstName , String lastName , String address ,
			String city , String state , String zipCode , String ssn) {
		firstNameTxt.sendKeys(firstName);
		lastNameTxt.sendKeys(lastName);
		
		addressTxt.sendKeys(address);
		cityTxt.sendKeys(city);
		stateTxt.sendKeys(state);
		zipCodeTxt.sendKeys(zipCode);
		
		ssnTxt.sendKeys(ssn);
		
		findMyLogInInfoBtn.click();
	}
	
	
	
}
