package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class TransferFundsPage extends PageBasePara {

	public TransferFundsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "amount")
	WebElement AmountTxt;
	
	@FindBy(id = "fromAccountId")
	WebElement fromAccountSelect;
	
	@FindBy(id = "toAccountId")
	WebElement toAccountSelect;
	
	@FindBy(xpath =  "//*[@id=\"transferForm\"]/div[2]/input")
	WebElement transferBtn;
	
	
	@FindBy(xpath =  "//*[@id=\"showForm\"]/h1")
	public WebElement transferFundsMSG;
	
	@FindBy(xpath =  "//*[@id=\"showResult\"]/h1")
	public WebElement transferComplete;
	
	
	
	
	public void transferFunds(String Amount) {
		Select fromAccountList = new Select(fromAccountSelect);
		Select toAccountList = new Select(toAccountSelect);
		
		AmountTxt.sendKeys(Amount);
		
		fromAccountList.getFirstSelectedOption();
		toAccountList.getFirstSelectedOption();
		
		transferBtn.click();
	}
	
	
	
}
