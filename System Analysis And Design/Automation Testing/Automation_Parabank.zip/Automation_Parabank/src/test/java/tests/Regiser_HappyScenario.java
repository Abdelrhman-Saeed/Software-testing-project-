package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;


public class Regiser_HappyScenario{
	WebDriver driver;
	String baseUrl ="https://parabank.parasoft.com/parabank/index.htm?ConnType=JDBC";
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
	
	@BeforeTest
	public void before() {
		 driver=new EdgeDriver();
		  driver.manage().window().maximize();
		  driver.navigate().to(baseUrl);
	}
	
	
	
  @Test
  public void UserCanRegister_HappyScenario() throws InterruptedException {
	  logInObject = new LoginPage(driver);
	  RegisterObject= new RegisterPage(driver);
	  homeObject = new HomePage(driver);
	  Thread.sleep(3000);
	  
	  logInObject.enterRegisterPage();
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/h1")).getText(), "Signing up is easy!");
	  Thread.sleep(3000);
	  
	  RegisterObject.customerCanRegister();
	  Thread.sleep(3000);
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/p")).getText(),"Your account was created successfully. You are now logged in.");
	  
      
	  
  }
  
  
  @AfterTest
  public void aftertest() {
	  driver.manage().deleteAllCookies(); 
	  driver.quit();
 }
  
//  @Test
// public void zUserCanLogOut() throws InterruptedException {
//	  homeObject = new HomePage(driver);
//	  homeObject.UserLogsOutbtn();
//	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"topPanel\"]/p")).getText(), "Experience the difference");
//	  Thread.sleep(2000);
//  }
//  
//  @Test
//  public void zuserOpensNewAccount() throws InterruptedException {
//	  homeObject = new HomePage(driver);
//	  homeObject.EnterOpenNewAccount();
//	  Thread.sleep(2000);
//	  
//  }
  
  
  
  
  
  
  
}
