package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.OpenNewAccPage;
import pages.RegisterPage;

public class OpenNewAccount_HappyScenario extends TestBase {
	
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
	OpenNewAccPage openObNewAccountOpject;
  @Test
  public void AUserCanRegister() throws InterruptedException {
	  logInObject = new LoginPage(driver);
	  RegisterObject= new RegisterPage(driver);
	  homeObject = new HomePage(driver);
	  Thread.sleep(3000);
	  
	  logInObject.enterRegisterPage();
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/h1")).getText(), "Signing up is easy!");
	  Thread.sleep(3000);
	  
	  RegisterObject.customerCanRegister();
	  Thread.sleep(3000);
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/p")).getText(),"Your account was created successfully. You are now logged in.");
	  
	  
  }
	@Test
  public void BopenNewAccount_HappyScenario() throws InterruptedException {
		openObNewAccountOpject = new OpenNewAccPage(driver);
		homeObject = new HomePage(driver);
		
		homeObject.goToOpenNewAccount();
		Thread.sleep(3000);
		Assert.assertTrue(openObNewAccountOpject.openNewAccountMSG.isDisplayed());
		
		openObNewAccountOpject.openNewAccount();
		Thread.sleep(3000);
		Assert.assertTrue(openObNewAccountOpject.accountOpenedMSG.isDisplayed());
		
		openObNewAccountOpject.openAccountDetailsPage();
		Thread.sleep(3000);
		openObNewAccountOpject.userCanCheckNewAccountActivity();
		Thread.sleep(3000);
		Assert.assertTrue(openObNewAccountOpject.TransferMSG.isDisplayed());
  }
	
}
