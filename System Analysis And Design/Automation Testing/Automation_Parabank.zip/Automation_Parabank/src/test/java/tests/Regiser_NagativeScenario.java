package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;


public class Regiser_NagativeScenario extends TestBase{
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
  @Test
  public void UserCanRegister_HappyScenario() throws InterruptedException {
	  logInObject = new LoginPage(driver);
	  RegisterObject= new RegisterPage(driver);
	  Thread.sleep(3000);
	  
	  logInObject.enterRegisterPage();
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/h1")).getText(), "Signing up is easy!");
	  Thread.sleep(3000);
	  
	  RegisterObject.customerCanRegister();
	  Thread.sleep(3000);
	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/p")).getText(),"Your account was created successfully. You are now logged in.");
  }
  
  
//  @Test
// public void zUserCanLogOut() throws InterruptedException {
//	  homeObject = new HomePage(driver);
//	  homeObject.UserLogsOutbtn();
//	  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"topPanel\"]/p")).getText(), "Experience the difference");
//	  Thread.sleep(2000);
//  }
  
//  @Test
//  public void zuserOpensNewAccount() throws InterruptedException {
//	  homeObject = new HomePage(driver);
//	  homeObject.EnterOpenNewAccount();
//	  Thread.sleep(2000);
//	  
//  }
  
  
  
  
  
  
  
}
