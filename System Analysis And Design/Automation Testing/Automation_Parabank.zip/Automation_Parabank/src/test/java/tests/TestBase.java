package tests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;

public class TestBase {
	

	
	WebDriver driver;
	String baseUrl ="https://parabank.parasoft.com/parabank/index.htm?ConnType=JDBC";
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
  @BeforeTest
  public void f() throws InterruptedException {
	  driver=new EdgeDriver();
	  driver.manage().window().maximize();
	  driver.navigate().to(baseUrl);
		  logInObject = new LoginPage(driver);
		  RegisterObject= new RegisterPage(driver);
		  homeObject = new HomePage(driver);
		  Thread.sleep(3000);
		  
		  logInObject.enterRegisterPage();
		  Thread.sleep(3000);
		  
		  RegisterObject.customerCanRegister();
		  Thread.sleep(3000);
		  
		  
	      
		  
	  }
  
  
  @AfterTest
   public void aftertest() {
	  driver.manage().deleteAllCookies(); 
	  driver.quit();
  }
}
