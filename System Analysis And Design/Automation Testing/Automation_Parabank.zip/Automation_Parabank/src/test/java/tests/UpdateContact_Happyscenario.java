package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.UpdateContactPage;

public class UpdateContact_Happyscenario extends TestBase {
		HomePage homeObject;
		UpdateContactPage updateObject;
  @Test
  public void updateinfo() throws InterruptedException {
	  homeObject = new HomePage(driver);
	  updateObject = new UpdateContactPage(driver);
	  
	  homeObject.goToUpdateContactInfo();
	  Assert.assertTrue(updateObject.UdpateProfileMsg.isDisplayed());
	  Thread.sleep(3000);
	  updateObject.customerCanUpdate();
	  Thread.sleep(5000);
	  Assert.assertTrue(updateObject.UpdatedMsg.isDisplayed());
  }
  
  
}
