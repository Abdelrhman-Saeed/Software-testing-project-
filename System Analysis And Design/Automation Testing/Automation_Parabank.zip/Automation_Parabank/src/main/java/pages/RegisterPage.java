package pages;

import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends PageBasePara{
	
	public RegisterPage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(id="customer.firstName")
	WebElement firstNameTxt;
	
	@FindBy(id="customer.lastName")
	WebElement lastNameTxt;
	
	@FindBy(id="customer.address.street")
	WebElement addressTxt;
	
	@FindBy(id="customer.address.city")
	WebElement cityTxt;
	
	@FindBy(id="customer.address.state")
	WebElement stateTxt;
	
	@FindBy(id="customer.address.zipCode")
	WebElement zipCodeTxt;
	
	@FindBy(id="customer.phoneNumber")
	WebElement phoneTxt;
	
	@FindBy(id="customer.ssn")
	WebElement ssnTxt;
	
	@FindBy(id="customer.username")
	public WebElement userNameTxt;
	
	@FindBy(id="customer.password")
	WebElement passWordTxt;
	
	@FindBy(id="repeatedPassword")
	WebElement confirmPassWordTxt;
	
	@FindBy(xpath="//*[@id=\"customerForm\"]/table/tbody/tr[13]/td[2]/input")
	WebElement registerBtn;

	public void customerCanRegister()
	{
	        
		firstNameTxt.sendKeys("Paraban");
		lastNameTxt.sendKeys("money");
		
		addressTxt.sendKeys("roxy");
		cityTxt.sendKeys("cairo");
		stateTxt.sendKeys("cairo");
		zipCodeTxt.sendKeys("123456");
		
		phoneTxt.sendKeys("01010101010");
		ssnTxt.sendKeys("123456");
		
	    userNameTxt.sendKeys("test62");
		passWordTxt.sendKeys("bank");
		confirmPassWordTxt.sendKeys("bank");
		
		registerBtn.click();
	}
	
	
	
}
