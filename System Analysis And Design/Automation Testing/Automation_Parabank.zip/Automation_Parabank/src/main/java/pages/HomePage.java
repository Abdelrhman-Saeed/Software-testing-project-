package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBasePara {

	public HomePage(WebDriver driver) {
		super(driver);
		
	}

	@FindBy(xpath="//*[@id=\"leftPanel\"]/ul/li[1]/a")
	WebElement openNewAcountLink;
	
	@FindBy(linkText =  "Log Out")
	WebElement logOutBtn;
	
	@FindBy(xpath = "//*[@id=\"showOverview\"]/h1")
	public WebElement accOverview;
	
	@FindBy (xpath = "//*[@id=\"leftPanel\"]/ul/li[6]/a")
	WebElement UpdateLinkBtn;
	
	public void goToOpenNewAccount() {
		openNewAcountLink.click();
	}
	public void UserLogsOutbtn() {
		logOutBtn.click();
		
	}
	
	public void goToUpdateContactInfo() {
		UpdateLinkBtn.click();
		
	}
	

	
	
	
}
