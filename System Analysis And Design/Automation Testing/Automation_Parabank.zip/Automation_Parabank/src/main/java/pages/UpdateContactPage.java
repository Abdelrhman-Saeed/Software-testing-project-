package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UpdateContactPage extends PageBasePara{

	public UpdateContactPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id="customer.firstName")
	WebElement firstNameTxt;
	
	
	@FindBy(id="customer.lastName")
	WebElement lastNameTxt;
	
	
	@FindBy(id="customer.address.street")
	WebElement addressTxt;
	
	
	@FindBy(id="customer.address.city")
	WebElement cityTxt;
	
	
	@FindBy(id="customer.address.state")
	WebElement stateTxt;
	
	
	@FindBy(id="customer.address.zipCode")
	WebElement zipCodeTxt;
	
	@FindBy(id="customer.phoneNumber")
	WebElement phoneTxt;
	
	@FindBy(xpath = "//*[@id=\"updateProfileForm\"]/form/table/tbody/tr[8]/td[2]/input")
	WebElement updateProfileBtn;
	
	@FindBy(xpath = "//*[@id=\"updateProfileForm\"]/h1")
	public WebElement UdpateProfileMsg;
	
	@FindBy(xpath = "//*[@id=\"updateProfileResult\"]/h1")
	public WebElement UpdatedMsg;
	
	public void customerCanUpdate()
	{
		
		firstNameTxt.clear();
		lastNameTxt.clear();
		
		addressTxt.clear();
		cityTxt.clear();
		stateTxt.clear();
		zipCodeTxt.clear();
		
		phoneTxt.clear();
		
		
	        
		firstNameTxt.sendKeys("Paraban");
		lastNameTxt.sendKeys("Zoubaa");
		
		addressTxt.sendKeys("roxy");
		cityTxt.sendKeys("nozha");
		stateTxt.sendKeys("nozha");
		zipCodeTxt.sendKeys("123456");
		
		phoneTxt.sendKeys("99999999999");
		
		updateProfileBtn.click();
		
	}
	
	
}
