package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class RequestLoanPage extends PageBasePara {

	public RequestLoanPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "amount")
	WebElement loanAmountTxt;
	
	@FindBy(id = "downPayment")
	WebElement downPaymentTxt;
	
	@FindBy(id = "fromAccountId")
	WebElement fromAccountList;
	
	@FindBy(xpath = "//*[@id=\"requestLoanForm\"]/form/table/tbody/tr[4]/td[2]/input")
	WebElement applyNowLoanBtn;
	
	@FindBy(xpath = "//*[@id=\"requestLoanForm\"]/h1")
	public WebElement applyForLoanMSG;
	
	@FindBy(xpath = "//*[@id=\"requestLoanResult\"]/h1")
	public WebElement processedMSG;
	
	public void requestLoan(String loanAmount,String downpaymentAmount) {
		Select fromaccountlist = new Select(fromAccountList);
		
		loanAmountTxt.sendKeys(loanAmount);
		downPaymentTxt.sendKeys(downpaymentAmount);
		
		fromaccountlist.getFirstSelectedOption();
		
		applyNowLoanBtn.click();
	}
	
	
}
