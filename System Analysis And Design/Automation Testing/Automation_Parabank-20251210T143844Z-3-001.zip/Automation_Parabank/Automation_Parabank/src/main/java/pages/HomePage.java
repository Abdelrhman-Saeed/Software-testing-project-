package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBasePara {

	public HomePage(WebDriver driver) {
		super(driver);
		
	}

	@FindBy(xpath="//*[@id=\"leftPanel\"]/ul/li[1]/a")
	WebElement openNewAcountLink;
	
	@FindBy(xpath =   "//*[@id=\"leftPanel\"]/ul/li[8]/a")
	WebElement logOutBtn;
	
	@FindBy(xpath = "//*[@id=\"showOverview\"]/h1")
	public WebElement accOverview;
	
	@FindBy (xpath = "//*[@id=\"leftPanel\"]/ul/li[6]/a")
	WebElement UpdateLinkBtn;
	
	@FindBy (xpath = "//*[@id=\"leftPanel\"]/ul/li[7]/a")
	WebElement RequestLoanBtn;
	
	@FindBy (xpath = "//*[@id=\"leftPanel\"]/ul/li[3]/a")
	WebElement TransferFundsBtn;
	
	@FindBy (xpath = "//*[@id=\"leftPanel\"]/ul/li[4]/a")
	WebElement BillpayBtn;
	
	
	
	@FindBy(xpath = "//*[@id=\"rightPanel\"]/p")
	public WebElement welcomeMSG;
	
	
	public void goToOpenNewAccount() {
		openNewAcountLink.click();
	}
	
	public void UserLogsOutbtn() {
		logOutBtn.click();
	}
	
	public void goToUpdateContactInfo() {
		UpdateLinkBtn.click();
	}
	
	public void goToRequestLoan() {
		RequestLoanBtn.click();
	}
	
	public void goToTransferFunds() {
		TransferFundsBtn.click();
	}
	
	public void goToBillpay() {
		BillpayBtn.click();
	}
	

	
	
	
}
