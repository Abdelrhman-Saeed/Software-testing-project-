package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginPage extends PageBasePara {

	
	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath="//*[@id=\"loginPanel\"]/p[2]/a")
	WebElement registerLink;
	
	@FindBy(xpath="//*[@id=\"loginPanel\"]/p[1]/a")
	WebElement forgetLoginInfoLink;
	
	@FindBy(name = "username")
	WebElement userName;
	
	@FindBy (name = "password")
	WebElement passWord;
	
	@FindBy(xpath = "//*[@id=\"loginPanel\"]/form/div[3]/input")
	WebElement logInBtn;
	
	
	@FindBy(xpath = "//*[@id=\"leftPanel\"]/h2")
	public WebElement CustomerLoginMSG;
	
	@FindBy(xpath = "//*[@id=\"rightPanel\"]/p")
	public WebElement errorLoginMSG;
	
	public void enterRegisterPage() {
		registerLink.click();
	}
	
	public void enterForgetLoginInfoPage() {
		forgetLoginInfoLink.click();
	}
	
	public void RegisteredUserLogIn(String user ,String pass) {
	
		userName.sendKeys(user);
		passWord.sendKeys(pass);
		
		logInBtn.click();
	}
	
	
	
}
