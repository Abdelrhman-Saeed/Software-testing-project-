package tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;

public class Login_HappyScenario extends TestBase {
	
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeOpject;
	long time = System.currentTimeMillis();
 
  
  @Test
  public void userLogin_HappySceanrio() throws InterruptedException {
	  homeObject = new HomePage(driver);
	  logInObject = new LoginPage(driver);
	  homeObject.UserLogsOutbtn();
//	  Thread.sleep(100);
	  logInObject.RegisteredUserLogIn( "Para"+time,"bank");
//	  Thread.sleep(100);
	  Assert.assertTrue(homeObject.accOverview.isDisplayed());
  }
  
  
  
  
  
}
