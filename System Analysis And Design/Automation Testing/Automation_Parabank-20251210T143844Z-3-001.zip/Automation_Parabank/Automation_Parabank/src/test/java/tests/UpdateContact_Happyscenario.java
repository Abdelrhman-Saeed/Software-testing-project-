package tests;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.UpdateContactPage;

public class UpdateContact_Happyscenario extends TestBase {
		HomePage homeObject;
		UpdateContactPage updateObject;
  @Test
  public void updateinfo_HappyScenario() throws InterruptedException{
	  homeObject = new HomePage(driver);
	  updateObject = new UpdateContactPage(driver);
	  
	  homeObject.goToUpdateContactInfo();
	  Thread.sleep(1000);
	  Assert.assertTrue(updateObject.UdpateProfileMsg.isDisplayed());
	  Thread.sleep(1000);
	  
	  updateObject.customerCanUpdate("newfirst","newlast",
			  	"newaddress","newcity","newstate","098765","0123456789");
	  Thread.sleep(1000);
	  Assert.assertTrue(updateObject.UpdatedMsg.isDisplayed());
  }
  
  
}
