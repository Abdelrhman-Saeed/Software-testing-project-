package tests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;

public class TestBase {
	
//	int rand = (int) (Math.random() * 100000);
	long time = System.currentTimeMillis();
	
	WebDriver driver;
	String baseUrl ="https://parabank.parasoft.com/parabank/index.htm?ConnType=JDBC";
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
  @BeforeTest
  public void f() throws InterruptedException {
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.navigate().to(baseUrl);
		  logInObject = new LoginPage(driver);
		  RegisterObject= new RegisterPage(driver);
		  homeObject = new HomePage(driver);
//		  Thread.sleep(3000);
		  
		  logInObject.enterRegisterPage();
//		  Thread.sleep(3000);
		  
		  RegisterObject.customerCanRegister("para","bank", "Roxy", "cairo" , "Misr el gededa",
				  "123456", "010111111111", "123456", "Para"+time, "bank");
//		  Thread.sleep(3000);
		  
		  
	      
		  
	  }
  
  
  @AfterTest
   public void aftertest() {
	  driver.manage().deleteAllCookies(); 
	  driver.quit();
  }
}
