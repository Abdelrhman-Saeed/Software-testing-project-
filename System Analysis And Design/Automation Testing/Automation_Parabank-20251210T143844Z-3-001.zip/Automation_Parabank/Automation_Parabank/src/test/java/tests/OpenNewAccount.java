package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.OpenNewAccPage;
import pages.RegisterPage;

public class OpenNewAccount extends TestBase {
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
	OpenNewAccPage openNewAccountOpject;
	@Test
  public void openNewAccount() throws InterruptedException {
		openNewAccountOpject = new OpenNewAccPage(driver);
		homeObject = new HomePage(driver);
		
		homeObject.goToOpenNewAccount();
		Thread.sleep(1000);
		Assert.assertTrue(openNewAccountOpject.openNewAccountMSG.isDisplayed());
		
		openNewAccountOpject.openNewAccount();
		Thread.sleep(1000);
		Assert.assertTrue(openNewAccountOpject.congratulationMSG.isDisplayed());
		
		openNewAccountOpject.openAccountDetailsPage();
		openNewAccountOpject.userCanCheckNewAccountActivity();
  }
	
}
