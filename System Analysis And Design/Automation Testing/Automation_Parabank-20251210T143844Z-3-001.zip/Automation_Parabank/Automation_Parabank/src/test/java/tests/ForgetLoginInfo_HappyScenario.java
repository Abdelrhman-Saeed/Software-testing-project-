package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ForgetLoginInfoPage;
import pages.HomePage;
import pages.LoginPage;

public class ForgetLoginInfo_HappyScenario extends TestBase{
	LoginPage logInObject;
	HomePage homeObject;
	ForgetLoginInfoPage forgetObject;
	
  @Test(priority = 1)
  public void LogOutAfterRegister() throws InterruptedException {
	  homeObject = new HomePage(driver);
	  logInObject = new LoginPage(driver);
//	  Thread.sleep(3000);
	    
	  homeObject.UserLogsOutbtn();
//	  Thread.sleep(3000);
	  Assert.assertTrue(logInObject.CustomerLoginMSG.isDisplayed());
  }
  
  @Test(priority = 2)
  public void forgetLoginInfo_HappyScenario() throws InterruptedException {
	  forgetObject = new ForgetLoginInfoPage(driver);
	  logInObject = new LoginPage(driver);
	  
	  logInObject.enterForgetLoginInfoPage();
//	  Thread.sleep(1000);
	  Assert.assertTrue(forgetObject.customerLookupMSG.isDisplayed());
	  
	  forgetObject.findMyLogInInfo("para","bank", "Roxy", "cairo" ,
			  					"Misr el gededa","123456","123456");
//	  Thread.sleep(3000);
  }
  
}
