package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;


public class Regiser_HappyScenario{
	WebDriver driver;
	String baseUrl ="https://parabank.parasoft.com/parabank/index.htm?ConnType=JDBC";
	LoginPage logInObject;
	RegisterPage RegisterObject;
	HomePage homeObject;
	
	int rand = (int) (Math.random() * 100000);

	
	@BeforeTest
	public void before() {
		 driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.navigate().to(baseUrl);
	}
	
	
	
  @Test
  public void UserCanRegister_HappyScenario() throws InterruptedException {
	  logInObject = new LoginPage(driver);
	  RegisterObject= new RegisterPage(driver);
	  homeObject = new HomePage(driver);
	  
	  logInObject.enterRegisterPage();
	  Assert.assertTrue(RegisterObject.regesterPageMSG.isDisplayed());
	  
	  RegisterObject.customerCanRegister("para","bank", "Roxy", "cairo" , "Misr el gededa",
			                         "123456", "010111111111", "123456", "Para"+rand, "bank");
	  Assert.assertTrue(homeObject.welcomeMSG.isDisplayed());
  }
  
  @AfterTest
  public void aftertest() {
	  driver.manage().deleteAllCookies(); 
	  driver.quit();
 }
  
}
